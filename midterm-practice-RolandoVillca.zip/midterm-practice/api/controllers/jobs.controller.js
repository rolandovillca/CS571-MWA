const mongoose = require("mongoose");
const Job = mongoose.model(process.env.JOB_MODEL);

const getAll = (req, res) => {
    Job.find().exec((err, jobs) => {
        console.log("Found jobs, jobs");
        res.status(200).json(jobs);
    });
}

const getOne = (req, res) => {
    const jobId = req.params.jobId;
    Job.findById(jobId).exec((err, job) => {
        const response = {
            status: 200,
            message: job
        }
        if (err) {
            console.log("Error finding Job");
            response.status = 500;
            response.message = err;
        }
        res.status(response.status).json(response.message);
    });
}

const addOne = (req, res) => {
    console.log("Adding job");
    const newJob = {
        title: req.body.title,
        salary: req.body.salary,
        location: {},
        description: req.body.description,
        experience: req.body.experience,
        skills: [],
        postDate: Date.now()
    };
    Job.create(newJob, (err, job) => {
        const response = { status: 200, message: job};
        if (err) {
            console.log("Error saving job: " + err);
            response.status = 500;
            response.message = err;
        }
        res.status(response.status).json(response.message);
    });
}

const deleteOne = (req, res) => {
    console.log("Deleting one job");
}

const updateOne = (req, res) => {}

module.exports = {
    getAll,
    getOne,
    addOne,
    deleteOne,
    updateOne
}