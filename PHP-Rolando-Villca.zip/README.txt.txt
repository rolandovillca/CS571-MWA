How to import dabatabase:
=========================
mongoimport --db swimmingDB --collection teams swimming-teams.json


Features Implemented:
=====================
1. Backend - Mongoose for MongoDB
2. Backend - CRUD teams
3. Backend - Routings
4. Backend - Controllers
5. Backend - Registro and Login
6. Backend - Using Named Callbacks and Promises
7. Backend - Variable Environments - Constants

8. FrontEnd: CRUD for teams
9. FrontEnd: Services, Components
10. FrontEnd: Teams Components
